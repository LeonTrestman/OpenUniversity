public interface Reverseable <T>{
    public T reverse() throws Exception;
}
